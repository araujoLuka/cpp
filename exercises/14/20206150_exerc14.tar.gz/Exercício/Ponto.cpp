#include "Ponto.hpp"

Ponto::Ponto(const double coordX, const double coordY)
		:coordX(coordX), coordY(coordY){
}
